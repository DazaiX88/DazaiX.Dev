func isOdd(n: Int) -> Bool {
if n % 2 == 0 {
    return true
}else{
    return false
}
}
    var thisIsOdd = isOdd(n: 10)

