

func greeting() {
    print("hello")
}
func greeting2(whoToGreet: String) {
    print("hello \(whoToGreet)")
}
greeting2(whoToGreet: "Angela")
greeting2(whoToGreet: "Delon")
